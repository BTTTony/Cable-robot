

cd osal
make clean
cd ../oshw
make clean
cd ../soem
make clean
cd ../test/slaveInfo
make clean
cd ../xmc4800
make clean
cd ../xmc4800_dc
make clean
cd ..
cd ..


