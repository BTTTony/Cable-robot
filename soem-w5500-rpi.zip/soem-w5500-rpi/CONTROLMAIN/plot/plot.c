#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
/*
int main()
{
    FILE *gnuplot = popen("gnuplot -persist", "w"); // Open gnuplot in persistent mode
    fprintf(gnuplot, "set term png\n"); // Set the output file format to PNG
    fprintf(gnuplot, "set output 'output.png'\n"); // Set the output file name
    fprintf(gnuplot, "plot sin(x)\n"); // Plot the sin(x) graph
    fclose(gnuplot); // Close gnuplot
    return 0;
}
*/
int main() {
    FILE *fp;
    double x, y;
    //char *gnuplotCommands[] = {"set title 'Velocity of axis 1", "set xlabel 'Time (s)'", "rt_ts'", "plot 'data.csv' with lines lc 22"};//linespoints"};
    char *gnuplotCommands[] = {"set title 'diff time", "set xlabel 'Time (s)'", "set ylabel 'Time (ps)'", "plot 'data.csv' with lines lc 6"};//linespoints"};
    
    int i, numCommands = sizeof(gnuplotCommands)/sizeof(char*);
    FILE *gnuplotPipe = popen("gnuplot -persistent", "w");

    // Open file CSV
    fp = fopen("data.csv", "r");
    if(fp == NULL) {
        printf("Cannot open file\n");
        exit(1);
    }

    // Read data from CSV file
    while(fscanf(fp, "%lf,%lf\n", &x, &y) == 2) {
        printf("%lf, %lf\n", x, y);
    }

    fclose(fp);

    // Send commands to GNUplot
    for(i = 0; i < numCommands; i++) {
        fprintf(gnuplotPipe, "%s\n", gnuplotCommands[i]);
    }

     pclose(gnuplotPipe);

    return 0;

}
/*
int main() {
    FILE *fp = fopen("data.csv", "r"); // Mở file data.csv để đọc

    // Tạo file tạm temp.txt để lưu dữ liệu với định dạng phù hợp với gnuplot
    FILE *temp = fopen("temp.txt", "w");

    // Đọc dữ liệu từ file data.csv và ghi vào file temp.txt
    char line[2560];
    while (fgets(line, sizeof(line), fp)) {
        float x, y1, y2, y3;
        sscanf(line, "%f,%f,%f", &x, &y1, &y2, &y3);
        fprintf(temp, "%f %f %f\n", x, y1, y2, y3);
    }

    // Đóng file data.csv và temp.txt
    fclose(fp);
    fclose(temp);

    // Sử dụng gnuplot để vẽ biểu đồ
    FILE *gnuplot = popen("gnuplot -persistent", "w");
    fprintf(gnuplot, "set xlabel 'X'\n");
    fprintf(gnuplot, "set ylabel 'Y'\n");
    fprintf(gnuplot, "plot 'temp.txt' using 1:2 with lines title 'Y1', using 1:3 with lines title 'Y2', using 1:4 with lines title 'Y3'\n");
    fflush(gnuplot);
    pclose(gnuplot);

    return 0;
}

//#include "gnuplot_i.h"

int main()
{
    FILE *csv_file = fopen("data.csv", "r");
    if (csv_file == NULL) {
        printf("Could not open file\n");
        return 1;
    }

    gnuplot_ctrl *plot;
    plot = gnuplot_init();
    gnuplot_setstyle(plot, "lines");

    // Đọc dữ liệu từ file CSV và vẽ đồ thị
    double x, y1, y2, y3;
    while (fscanf(csv_file, "%lf,%lf,%lf,%lf", &x, &y1, &y2, &y3) == 4) {
        gnuplot_plot_xy(plot, &x, &y1, 1, "y1", "lines", "1", "red");
        gnuplot_plot_xy(plot, &x, &y2, 1, "y2", "lines", "2", "blue");
        gnuplot_plot_xy(plot, &x, &y3, 1, "y3", "lines", "3", "green");
    }

    gnuplot_close(plot);
    fclose(csv_file);
    return 0;
}
*/
