
#include <stdio.h>

int global_var = 0; // global variable

int main() {
    while(1) {
        // print the current value of the global variable and prompt the user for input
        printf("The current value of global_var is %d. Enter a new value: ", global_var);
        
        // read an integer from the user
        int new_value;
        scanf("%d", &new_value);
        
        // update the global variable with the new value
        global_var = new_value;
        
        // do other stuff with global_var...
    }
    
    return 0;
}
