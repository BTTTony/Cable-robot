/* 
 * SOEM EtherCAT exmaple
 * Ported to raspberry pi by Ho Tam - thanhtam.h[at]gmail.com 
 */
 

#ifndef _PDO_DEF_
#define _PDO_DEF_

#include "servo_def.h"

//MAXPOS PDO mapping

typedef union _mapping_obj{
	uint32_t obj;
	struct {
		uint16_t index;
		uint8_t subindex;
		uint8_t size;
	};
} mapping_obj;

//0x1600 RxPDO
typedef struct PACKED
{
	UINT16	ControlWord;		//0x6040
	INT32	TargetPosition;		//0x607A
	INT32	TargetVelocity;		//0x60FF
	INT16	TargetTorque;		//0x6071
	UINT8	ModeOfOperation;	//0x6060
	UINT8	Padding;			//0x0000
	UINT16	TouchProbeFunction;	//0x60B8
}
MAXPOS_DRIVE_RxPDO_t;

//0x1A00 TxPDO
typedef struct PACKED
{
	UINT16	StatusWord;					//0x6041
	INT32	PositionActualValue;		//0x6064
	INT32	VelocityActualValue;		//0x606C
	INT16	TorqueActualValue;			//0x6077
	UINT8	ModeOfOperationDisplay;		//0x6061
	UINT8	ErrorRegister;				//0x1001
	UINT32	FollowingErrorActualValue;	//0x60FD
	UINT16	TouchProbeStatus;			//0x60B9
	UINT16	ErrorCode;					//0x60B9
	UINT32	DigitalInput;				//0x60FD
}MAXPOS_DRIVE_TxPDO_t;


typedef struct _MAXPOS_ServoDrive
{
	MAXPOS_DRIVE_RxPDO_t 	OutParam;
	MAXPOS_DRIVE_TxPDO_t 	InParam;
} MAXPOS_ServoDrive_t;

typedef struct _MAXPOS_Drive_pt
{
	MAXPOS_DRIVE_RxPDO_t 	*ptOutParam;
	MAXPOS_DRIVE_TxPDO_t 	*ptInParam;
} MAXPOS_Drive_pt;


#endif //_PDO_DEF_

