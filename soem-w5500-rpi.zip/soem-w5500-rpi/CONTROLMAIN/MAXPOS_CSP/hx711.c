#include <pigpio.h>
#include "hx711.h"



//#############################################################################################
void hx711_delay_us(void)
{
//   uint32_t delay = _HX711_DELAY_US_LOOP;
//   while (delay > 0)
//   {
//     delay--;
//     //__NOP();
//     //__NOP();__NOP(); __NOP(); __NOP();
//   }
    gpioDelay(0);
}
//#############################################################################################
uint8_t hx711_init(hx711_t *hx711, uint16_t clk_pin, uint16_t dat_pin, uint16_t dat_pin2,
                uint16_t dat_pin3, uint16_t dat_pin4, uint16_t dat_pin5, uint16_t dat_pin6)
{
  hx711->clk_pin = clk_pin;
  hx711->dat_pin = dat_pin;
  hx711->dat_pin2 = dat_pin2;
  hx711->dat_pin3 = dat_pin3;
  hx711->dat_pin4 = dat_pin4;
  hx711->dat_pin5 = dat_pin5;
  hx711->dat_pin6 = dat_pin6;

  if (gpioInitialise() < 0)
    {
        // pigpio initialisation failed.
        return 1;
    }
    gpioSetMode(clk_pin, PI_OUTPUT); 
    gpioSetMode(dat_pin, PI_INPUT);
    gpioSetPullUpDown(dat_pin,PI_PUD_UP);
    gpioSetMode(dat_pin2, PI_INPUT);
    gpioSetPullUpDown(dat_pin2,PI_PUD_UP);
    gpioSetMode(dat_pin3, PI_INPUT);
    gpioSetPullUpDown(dat_pin3,PI_PUD_UP);
    gpioSetMode(dat_pin4, PI_INPUT);
    gpioSetPullUpDown(dat_pin4,PI_PUD_UP);
    gpioSetMode(dat_pin5, PI_INPUT);
    gpioSetPullUpDown(dat_pin5,PI_PUD_UP);
    gpioSetMode(dat_pin6, PI_INPUT);
    gpioSetPullUpDown(dat_pin6,PI_PUD_UP);
    printf( "Init gpio success\n" );

  gpioWrite(clk_pin, 1);
  hx711_delay(10);
  gpioWrite(clk_pin, 0);
  hx711_delay(10);  
  hx711_value(hx711);
  hx711_value(hx711);
  return 0;
}
//#############################################################################################
void is_ready(hx711_t *hx711)
{
    while(gpioRead(hx711->dat_pin)  == 1);
    while(gpioRead(hx711->dat_pin2)  == 1);
    while(gpioRead(hx711->dat_pin3)  == 1);
    while(gpioRead(hx711->dat_pin4)  == 1);
    while(gpioRead(hx711->dat_pin5)  == 1);
    while(gpioRead(hx711->dat_pin6)  == 1);
}

//#############################################################################################
data_t hx711_value(hx711_t *hx711)
{
  uint32_t data1 = 0;
  uint32_t data2 = 0;
  uint32_t data3 = 0;
  uint32_t data4 = 0;
  uint32_t data5 = 0;
  uint32_t data6 = 0;
  data_t output;
  output.data1 =0;
  output.data2 =0;
  output.data3 =0;
  output.data4 =0;
  output.data5 =0;
  output.data6 =0;
  is_ready(hx711);
  // if (state>0)
  // {
  //   printf("Timeout : %d", state);
  // }
  for(int8_t i=0; i<24 ; i++)
  {
    gpioWrite(hx711->clk_pin, 1); 
    //hx711_delay_us();
    gpioWrite(hx711->clk_pin, 0); 
     //hx711_delay_us();
    data1 = data1 << 1;
    data2 = data2 << 1;
    data3 = data3 << 1;
    data4 = data4 << 1;
    data5 = data5 << 1;
    data6 = data6 << 1;
    if(gpioRead(hx711->dat_pin)  == 1)  data1 ++;
    if(gpioRead(hx711->dat_pin2)  == 1)  data2 ++;
    if(gpioRead(hx711->dat_pin3)  == 1)  data3 ++;
    if(gpioRead(hx711->dat_pin4)  == 1)  data4 ++;
    if(gpioRead(hx711->dat_pin5)  == 1)  data5 ++;
    if(gpioRead(hx711->dat_pin6)  == 1)  data6 ++;
  }
  output.data1 = (data1) ^ 0x800000;
  output.data2 = (data2) ^ 0x800000;
  output.data3 = (data3) ^ 0x800000;
  output.data4 = (data4) ^ 0x800000;
  output.data5 = (data5) ^ 0x800000;
  output.data6 = (data6) ^ 0x800000;
  // output.data1 = data;
  // output.data2 = data2;
  // output.data3 = data3;
  // output.data4 = data4;
  gpioWrite(hx711->clk_pin, 1); 
  //hx711_delay_us();
  gpioWrite(hx711->clk_pin, 0); 
  //hx711_delay_us();

  return output;
}
//#############################################################################################
weight_t hx711_weight(hx711_t *hx711, uint16_t sample)
{
  data_t data;
  weight_t answer;
 // int64_t  ave = 0;
//  for(uint16_t i=0 ; i<sample ; i++)
//  {
//    ave += hx711_value(hx711);
//    hx711_delay(5);
//  }
 // int32_t data = (int32_t)(ave / sample);

  data = hx711_value(hx711);
  answer.weight_1 = (data.data1 - hx711->offset) / hx711->coef;
  answer.weight_2 = (data.data2 - hx711->offset2) / hx711->coef2;
  answer.weight_3 = (data.data3 - hx711->offset3) / hx711->coef3;
  answer.weight_4 = (data.data4 - hx711->offset4) / hx711->coef4;
  answer.weight_5 = (data.data5 - hx711->offset5) / hx711->coef5;
  answer.weight_6 = (data.data6 - hx711->offset6) / hx711->coef6;
  //float answer =  (data - hx711->offset) / hx711->coef;
  return answer;
}
//#############################################################################################
void hx711_tare(hx711_t *hx711, uint16_t sample)
{
  ave_t  ave = {0};
  data_t data;
  for(uint16_t i=0 ; i<sample ; i++)
  {
    data = hx711_value(hx711);
    ave.data1 += data.data1;
    ave.data2 += data.data2;
    ave.data3 += data.data3;
    ave.data4 += data.data4;
    ave.data5 += data.data5;
    ave.data6 += data.data6;
    hx711_delay(5);
  }
  hx711->offset = (int32_t)(ave.data1 / sample);
  hx711->offset2 = (int32_t)(ave.data2 / sample);
  hx711->offset3 = (int32_t)(ave.data3 / sample);
  hx711->offset4 = (int32_t)(ave.data4 / sample);
  hx711->offset5 = (int32_t)(ave.data5 / sample);
  hx711->offset6 = (int32_t)(ave.data6 / sample);
  
}

//#############################################################################################
void hx711_coef_set(hx711_t *hx711, float coef, float coef2, float coef3,
                    float coef4,float coef5,float coef6)
{
  hx711->coef = coef;
  hx711->coef2 = coef2;
  hx711->coef3 = coef3;
  hx711->coef4 = coef4;
  hx711->coef5 = coef5;
  hx711->coef6 = coef6;  
}
//#############################################################################################
float hx711_coef_get(hx711_t *hx711)
{
  return hx711->coef;  
}
//#############################################################################################
void hx711_power_down(hx711_t *hx711)
{
  gpioWrite(hx711->clk_pin, 1); 
  gpioWrite(hx711->clk_pin, 0); 
  hx711_delay(1);  
}
//#############################################################################################
void hx711_power_up(hx711_t *hx711)
{
  gpioWrite(hx711->clk_pin, 0); 
}
//#############################################################################################
