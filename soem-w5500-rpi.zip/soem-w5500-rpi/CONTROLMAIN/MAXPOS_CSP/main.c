

 #include <stdlib.h>
#include <signal.h>
#include <stdio.h>

#include <sys/mman.h>

#include <alchemy/task.h>
#include <alchemy/timer.h>
#include <alchemy/sem.h>
#include <boilerplate/trace.h>
#include <xenomai/init.h>

#include "ethercattype.h"
#include "nicdrv.h"
#include "ethercatbase.h"
#include "ethercatmain.h"
#include "ethercatdc.h"
#include "ethercatcoe.h"
#include "ethercatfoe.h"
#include "ethercatconfig.h"
#include "ethercatprint.h"
#include "pdo_def.h"
#include "ecat_dc.h"
#include "wiznet_drv.h"

#include <pigpio.h>
#include "hx711.h"

#define NSEC_PER_SEC 			1000000000
#define EC_TIMEOUTMON 500
#define NUMOFMAXPOS_DRIVE	3
#define _USE_DC
//#define _WRITE_MODEOP_SDO

#define CLOCK 14
#define DATA1 15
#define DATA2 18
#define DATA3 23
#define DATA4 24
#define DATA5 25
#define DATA6 8
#define out 4

hx711_t loadcell;
weight_t weight;

MAXPOS_Drive_pt	maxpos_drive_pt[NUMOFMAXPOS_DRIVE];

unsigned int cycle_ns = 1000000;/* 1 ms */

char IOmap[4096];
//char IOmap[1024];
pthread_t thread1;
int expectedWKC;
boolean needlf;
volatile int wkc;
boolean inOP;
uint8 currentgroup = 0;

RT_TASK motion_task;
RT_TASK print_task;
RT_TASK eccheck_task;
RT_TASK loadcell_task;

RTIME now, previous;
long ethercat_time_send, ethercat_time_read=0;
long ethercat_time=0, worst_time=0;
char ecat_ifname[32]="PiCAT";
int run=1;
int sys_ready=0;

int started[NUMOFMAXPOS_DRIVE]={0}, ServoState=0;
uint8 servo_ready=0, servo_prestate=0;
int32_t zeropos[NUMOFMAXPOS_DRIVE]={0};
double gt=0;

double sine_amp=12000000, f=0.2, period, cc=10;
unsigned long long error=0;
int recv_fail_cnt=0, pre;
int PI = 3.141592654;
float ema_a = 0.1;
float ema_ema = 0;
float ema = 0;
float ZZ = 590; //toa do goc ban dau 
float cv = 590;
float X ,Y , Z = 590, l1, l2, l3, x, y, z, AA = 0, BB = 0, CC =590, t =0;
//float a=0 ,b=0,c=267,d;

int s=0, button, prepos;
/* KHONG DUNG 
float a[26]={0,0,10,20,0,20,20,0,0,50,50,50,50,90,90,50,90,90,100,100,100,20,140,140,0};
float b[26]={0,80,80,0,40,40,0,0,0,80,80,0,0,0,0,40,80,80,80,80,20,270,80,80,0};
float c[26]={640,640,640,180,640,640,180,640,627,627,640,640,627,627,640,640,640,627,627,640,640,90,640,627,627};
float d[26]={1,1,1,2,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1};	

float a[10]={2,0,0,0,0,0,0,0,0,0}; //2s (nghi)
float b[10]={0,0,0,0,0,0,0,0,0,0};
float c[10]={0,427,627,550,627,627,627,627,0,0};
float d[10]={3,1,1,0,0,0,0,0,0,0};

float a[10]={0,0,200,200,0,0,0,100,0,0};
float b[10]={0,200,0,0,0,0,100,0,0,0};
float c[10]={630,630,720,720,630,680,635,720,685,0};
float d[10]={1,1,2,3,1,1,0,0,0,0};

/*Do sai so lap lai bang cach cho di chuyen len va xuong 
//627: vi tri cham dong ho so
float a[12]={0,3,0,3,0,3,0,3,0,3,0,3};
float b[12]={0,0,0,0,0,0,0,0,0,0,0,0};
float c[12]={460,460,627,627,460,460,627,627,460,460,627,627};
float d[12]={1,3,1,3,1,3,1,3,1,3,1,3};
*/
//BKU
float a[26]={0,0,10,20,0,20,20,0,0,50,50,50,50,90,90,50,90,90,100,100,100,20,140,140,0};
float b[26]={0,80,80,0,40,40,0,0,0,80,80,0,0,0,0,40,80,80,80,80,20,270,80,80,0};
float c[26]={630,630,630,180,630,630,180,630,590,590,630,630,590,590,630,630,630,590,590,630,630,90,630,590,590};
float d[26]={1,1,1,2,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1};
/*
/*Ve 2 duong tron tren va duoi de kiem tra fuzzy - Co Fuzzy
float a[10]={0,0,200,0,200,0,8,200,0,0};
float b[10]={0,-200,-180,-200,-180,-200,0,-180,0,0};
float c[10]={540,540,180,500,180,540,0,180,540,590};
float d[10]={1,1,2,1,2,1,3,2,1,1};
*/
/*Ve 2 duong tron tren va duoi de kiem tra fuzzy - Khong co Fuzzy
float a[10]={0,0,200,0,200,0,8,200,0,0};
float b[10]={0,-200,-180,-200,-180,-200,0,-180,0,0};
float c[10]={540,540,180,500,180,540,0,180,540,590};
float d[10]={4,4,5,4,5,4,3,5,4,4};
*/
//variables for pdo re-mapping (sdo write)
int os;
uint32_t ob;
uint16_t ob2;
uint8_t  ob3;
uint8_t  ob4;

float inv_kine (float p1,float p2,float p3, int n)
{
	float l_top=435,l_bottom=35;
	float l=0, a1[3]={-l_top*(sqrt(3))/2, -l_top/2, 0}, a2[3]={l_top*(sqrt(3))/2, -l_top/2, 0}, a3[3]={0, l_top, 0};
	float b1[3]={-l_bottom*(sqrt(3))/2, -l_bottom/2, 0}, b2[3]={l_bottom*(sqrt(3))/2, -l_bottom/2, 0}, b3[3]={0, l_bottom, 0};
	switch (n)
	{
		case 1: 
			l=sqrt((a1[0]-p1-b1[0])*(a1[0]-p1-b1[0])+(a1[1]-p2-b1[1])*(a1[1]-p2-b1[1])+(a1[2]-p3-b1[2])*(a1[2]-p3-b1[2]));
			break;
		case 2: 
			l=sqrt((a2[0]-p1-b2[0])*(a2[0]-p1-b2[0])+(a2[1]-p2-b2[1])*(a2[1]-p2-b2[1])+(a2[2]-p3-b2[2])*(a2[2]-p3-b2[2]));
			break;
		case 3:
			l=sqrt((a3[0]-p1-b3[0])*(a3[0]-p1-b3[0])+(a3[1]-p2-b3[1])*(a3[1]-p2-b3[1])+(a3[2]-p3-b3[2])*(a3[2]-p3-b3[2]));
			break;
	}
		return l;	
}	
float *unit_vector (float p1,float p2,float p3, int n)
{
	static float u[3];
	float a1[3]={-l_top*(sqrt(3))/2, -l_top/2, 0}, a2[3]={l_top*(sqrt(3))/2, -l_top/2, 0}, a3[3]={0, l_top, 0};
	float b1[3]={-l_bottom*(sqrt(3))/2, -l_bottom/2, 0}, b2[3]={l_bottom*(sqrt(3))/2, -l_bottom/2, 0}, b3[3]={0, l_bottom, 0};
	switch (n)
	{
		case 1: 
			u[0]=a1[0]-p1-b1[0];
			u[1]=a1[1]-p2-b1[1];
			u[2]=a1[2]-p3-b1[2];			
			break;
		case 2:
			u[0]=a2[0]-p1-b2[0];
			u[1]=a2[1]-p2-b2[1];
			u[2]=a2[2]-p3-b2[2];
			break;
		case 3:
			u[0]=a3[0]-p1-b3[0];
			u[1]=a3[1]-p2-b3[1];
			u[2]=a3[2]-p3-b3[2];
			break;
	}
	return u;
}

float valueEnc(float a) //a: do dai day
{
    float b=0;
    b = (a*8388607*10)/(54*5*PI);
    return b; //tra ve gia tri thuc encoder doc duoc
}

float maxin3(float a1, float a2, float a3)
{
	float a = 0;
    if (a1 >= a2 && a1 >= a3)
    {
        a = a1;
    }
    else if (a2 >= a1 && a2 >= a3)
    {
        a = a2;
    }
    else 
    {
        a = a3;
    }
    return a;
}

float max(float a, float b)
{
    if (a > b)
    {
        return a;
    }else{
    return b;}
}

float min(float a, float b)
{
    if (a < b)
    {
        return a;
    }else{
    return b;}
}

float defuzzified_output(float a1, float a2, float a3, float p) //
{
    float l = 1, m = 0, h = 0, L = 1, M = 0, H = 0;
    float a = 0; 
	a=maxin3(a1,a2,a3);
    //Fuzzy_set_tension // luc cang day  5000-9000
    if (a < 5000) // Nam o doan LOW
    {
      l = 1;
      m = 0;
      h = 0;
    }
    if (a >= 5000 && a < 7000) //Nam trong MED va LOW
    {
      m = (a-5000)/(7000-5000);
      l = 1-m;
      h = 0;
    }
    if (a >= 7000 && a <9000) //Nam trong MED va HIGH
    {
      l = 0;
      m = (9000-a)/(9000-7000);
      h = 1-m;
    }
    if (a >= 9000) // thuoc qua HIGH
    {
      l = 0;
      m = 0;
      h = 1;
    }
    
     //Fuzzy_set_spring_load_lenght
    if (p < 400)
    {
      L = 0;
      M = 0;
      H = 1;
    }
    if (p >= 400 && p < 500)
    {
      L = 0;
      H = (500-p)/(500-400);
	  M = 1-H;
    }
    if (p >= 500 && p <600)
    {
      M = (600-p)/(600-500);
      L = 1-M;
      H = 0;
    }
    if (p >= 600)
    {
      L = 1;
      M = 0;
      H = 0;
    }
    // Define fuzzy rules
    return ((min(l,L)*1+(min(l,M)+min(m,L))*1.5+(min(m,M)+min(l,H)+min(h,L))*1.5+(min(h,M)+min(m,H))*0.5+min(h,H)*0)/(min(l,L)+min(l,M)+min(m,L)+min(m,M)+min(l,H)+min(h,L)+min(h,H)+min(h,M)+min(m,H)));
   // return ((min(l,L)*2.5+(min(l,M)+min(m,L))*2+(min(m,M)+min(l,H)+min(h,L))*1.5+(min(h,M)+min(m,H))*1+min(h,H)*0.5)/(min(l,L)+min(l,M)+min(m,L)+min(m,M)+min(l,H)+min(h,L)+min(h,H)+min(h,M)+min(m,H)));
    
    //return ((min(l,L)*2+(min(l,M)+min(m,L))*1.5+(min(m,M)+min(l,H))*1+(min(m,H))*0.5+(min(h,M)+min(h,L)+min(h,H))*0)/(min(l,L)+min(l,M)+min(m,L)+min(m,M)+min(l,H)+min(h,L)+min(h,H)+min(h,M)+min(m,H)));

}

void slp(float A, float B, float C) //ham dung im  //A: time(second)
{

	
			float T=A;
				
				if (t <= T)
				{
			
					l1 = l1;
					l2 = l2;
					l3 = l3;
					t+= period;
				}
				else 
				{
					s = s +1;
					t = 0;
					button = 0;
				}

			
}

void direct(float A, float B, float C) // A: x, B: y; C: Z
{	
			float T = (sqrt((AA-A)*(AA-A)+(BB-B)*(BB-B)+(CC-C)*(CC-C)))/100; //Tinh toan thoi gian hoan thanh (Quang duong / van toc (100 mm/s))
			//float T=(sqrt((AA-A)*(AA-A)+(BB-B)*(BB-B)+(CC-C)*(CC-C)))/50
				if (t <= T)
				{
					//vi tri s0
					x = X;
					y = Y;
					z = Z;
					//vi tri tiep theo trong chia diem s_t
					X = AA + ((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(A-AA); //T: t_f; P(t)= P(0) + s(t) (P(f)-P(0))
					Y = BB + ((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(B-BB);
					Z = CC + ((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(C-CC);
				/*Tinh toan chieu dai day tu s(t) - s(t-1)*/
					l1 = l1 + [inv_kine(X, Y, Z, 1)-inv_kine(x, y, z, 1)]; 
					l2 = l2 + [inv_kine(X, Y, Z, 2)-inv_kine(x, y, z, 2)];
					l3 = l3 + [inv_kine(X, Y, Z, 3)-inv_kine(x, y, z, 3)];
				/*check thoi gian : t ~ T (trong pham vi nho hon chu ki -> t=T)*/
				/*period = 1ms, chu ky lenh * thoi gian fuzzy -> chu ky chinh */
					if ((T-t) < period*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z))
					{
						t = T;
					}
					else
					{					
						t+= period*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z);
					}			
				}
				if (t >= T)  //Vi tri bat dau P0 la vi tri hien tai
				{
					AA = A;
					BB = B;
					CC = C;
					s = s +1;
					t = 0;
				}
}
void directNofuzzy(float A, float B, float C) // A: x, B: y; C: Z
{	
			float T = (sqrt((AA-A)*(AA-A)+(BB-B)*(BB-B)+(CC-C)*(CC-C)))/100; //Tinh toan thoi gian hoan thanh (Quang duong / van toc (100 mm/s))
			//float T=(sqrt((AA-A)*(AA-A)+(BB-B)*(BB-B)+(CC-C)*(CC-C)))/50
				if (t <= T)
				{
					//vi tri s0
					x = X;
					y = Y;
					z = Z;
					//vi tri tiep theo trong chia diem s_t
					X = AA + ((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(A-AA); //T: t_f; P(t)= P(0) + s(t) (P(f)-P(0))
					Y = BB + ((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(B-BB);
					Z = CC + ((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(C-CC);
				/*Tinh toan chieu dai day tu s(t) - s(t-1)*/
					l1 = l1 + [inv_kine(X, Y, Z, 1)-inv_kine(x, y, z, 1)]; 
					l2 = l2 + [inv_kine(X, Y, Z, 2)-inv_kine(x, y, z, 2)];
					l3 = l3 + [inv_kine(X, Y, Z, 3)-inv_kine(x, y, z, 3)];
				/*check thoi gian : t ~ T (trong pham vi nho hon chu ki -> t=T)*/
				/*period = 1ms, chu ky lenh * thoi gian fuzzy -> chu ky chinh */
					if ((T-t) < period);//*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z))
					{
						t = T;
					}
					else
					{					
						t+= period;//*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z);
					}			
				}
				if (t >= T)  //Vi tri bat dau P0 la vi tri hien tai
				{
					AA = A;
					BB = B;
					CC = C;
					s = s +1;
					t = 0;
				}
}


void circle720deg()
{	
			float  T = 12;
				

				if (t <= T)
				{
					x = X;
					y = Y;
					z = Z;
				/*Vi tri sau = vi tri dau - gia tri do quay nguoc chieu kim tu  0- 2pi*/ //100: ban kinh quay 100  
				//x(t)=x(0)+Rsins(t); s(0) =theta(0) ; s(tf) = theta(f)
				//s(t)=theta0 + (3/2...)(thetaf-theta0)
				//AA-100sin(0..) -> truy ve x0 : tam hinh tron
					X = AA - 100*sin(0*3.14159/180) + 100*sin((0+((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(720))*3.14159/180); // *3.14../180 -> chuyen tu do sang rad
					Y = BB - 100*cos(0*3.14159/180) + 100*cos((0+((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(720))*3.14159/180);
					Z = CC - 200*sin(3.14159*12/t);	
				
					l1 = l1 + [inv_kine(X, Y, Z, 1)-inv_kine(x, y, z, 1)];
					l2 = l2 + [inv_kine(X, Y, Z, 2)-inv_kine(x, y, z, 2)];
					l3 = l3 + [inv_kine(X, Y, Z, 3)-inv_kine(x, y, z, 3)];
					//t+= period;
					if ((T-t) < period);//*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z))
					{
						t = T;
					}else
					{					
						t+= period;//*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z);
					}			
				}
				if (t >= T) 
				{
					AA = X;
					BB = Y;
					CC = Z;
					s = s +1;
					t = 0;
				}
}

void circle(float A, float B, float C)
{

	
			float T= A*8*0.6*PI*(sqrt((B-C)*(B-C)))/(180*100); //Xem xet lai : T= S/V S=(DENTAPHI*R)
			//	float T= A*0.08*0.314159*(sqrt((B-C)*(B-C)))/(180);
				if (t <= T)
				{
					x = X;
					y = Y;
					z = Z;
				
					X = AA - A*sin(B*3.14159/180) + A*sin((B+((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(C-B))*3.14159/180);
					Y = BB - A*cos(B*3.14159/180) + A*cos((B+((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(C-B))*3.14159/180);
					Z = CC;// - ((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*140;// + 200*sin(3.1415*t/T);
				
					l1 = l1 + inv_kine(X, Y, Z, 1)-inv_kine(x, y, z, 1);
					l2 = l2 + inv_kine(X, Y, Z, 2)-inv_kine(x, y, z, 2);
					l3 = l3 + inv_kine(X, Y, Z, 3)-inv_kine(x, y, z, 3);
														
					if ((T-t) < period*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z))
					{
						t = T;
					}
					else
					{					
					t+= period*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z);
					}
				}
				if (t >= T) 
				{
					AA = X;
					BB = Y;
					CC = Z;
					s = s +1; // bien s cho mang
					t = 0;
				}

			
}	
void circleNoFuzzy(float A, float B, float C)
{

	
			float T= A*8*0.6*PI*(sqrt((B-C)*(B-C)))/(180*100); //Xem xet lai : T= S/V S=(DENTAPHI*R)
			//	float T= A*0.08*0.314159*(sqrt((B-C)*(B-C)))/(180);
				if (t <= T)
				{
					x = X;
					y = Y;
					z = Z;
				
					X = AA - A*sin(B*3.14159/180) + A*sin((B+((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(C-B))*3.14159/180);
					Y = BB - A*cos(B*3.14159/180) + A*cos((B+((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(C-B))*3.14159/180);
					Z = CC;// - ((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*140;// + 200*sin(3.1415*t/T);
				
					l1 = l1 + inv_kine(X, Y, Z, 1)-inv_kine(x, y, z, 1);
					l2 = l2 + inv_kine(X, Y, Z, 2)-inv_kine(x, y, z, 2);
					l3 = l3 + inv_kine(X, Y, Z, 3)-inv_kine(x, y, z, 3);
														
					if ((T-t) < period);//*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z))
					{
						t = T;
					}
					else
					{					
					t+= period;//*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z);
					}
				}
				if (t >= T) 
				{
					AA = X;
					BB = Y;
					CC = Z;
					s = s +1; // bien s cho mang
					t = 0;
				}

			
}	
void circlee(float A, float B, float C)
{

	
			float T= A*3*0.8*PI*0.01*(sqrt((B-C)*(B-C)))/(180*5);
			
			//float T= A*0.08*0.314159*(sqrt((B-C)*(B-C)))/(180);
				
				if (t <= T)
				{
					x = X;
					y = Y;
					z = Z;
				
					X = AA - A*sin(B*3.14159/180) + A*sin((B+((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(C-B))*3.14159/180);
					Y = BB - A*cos(B*3.14159/180) + A*cos((B+((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*(C-B))*3.14159/180);
					Z = CC + ((3*t*t)/(T*T)-2*t*t*t/(T*T*T))*140;// + 200*sin(3.1415*t/T);
				
					l1 = l1 + inv_kine(X, Y, Z, 1)-inv_kine(x, y, z, 1);
					l2 = l2 + inv_kine(X, Y, Z, 2)-inv_kine(x, y, z, 2);
					l3 = l3 + inv_kine(X, Y, Z, 3)-inv_kine(x, y, z, 3);
														
					if ((T-t) < period)//*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z))
					{
						t = T;
					}
					else
					{					
					t+= period;//*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z);
					}
				}
				if (t >= T) 
				{
					AA = X;
					BB = Y;
					CC = Z;
					s = s +1;
					t = 0;
					//button = 0;
					//button == 0;
				}

			
}

	

boolean ecat_init(void)
{
	int i, oloop, iloop, k, wkc_count;	
    needlf = FALSE;
    inOP = FALSE;

    rt_printf("Starting simple test\n");
	
	//wiznet_hw_config(16, 1, 1000000); //select SPI-W5500 parameters, before ec_init
	wiznet_hw_config(16, 0, 0); //31.25 Mhz, do not reset link 
	
    if (ec_init(ecat_ifname))
    {
      rt_printf("ec_init on %s succeeded.\n", ecat_ifname); 
      /* find and auto-config slaves */
		if ( ec_config_init(FALSE) > 0 )
		{
			 rt_printf("%d slaves found and configured.\n",ec_slavecount);
			 
			 //PDO re-mapping****************************************************************************************************
			 for (k=0; k<NUMOFMAXPOS_DRIVE; ++k)
			 {
				 if (( ec_slavecount >= 1 ) && (strcmp(ec_slave[k+1].name,"CSD7_04BN1") == 0)) //change name for other drives
				 {
					 printf("Remapping for CSD7_04BN1...\n");
					os=sizeof(ob4); ob4 = 0x00;
					wkc_count+=ec_SDOwrite(k+1, 0x1c12,0x00,FALSE,os, &ob4,EC_TIMEOUTRXM);
					wkc_count+=ec_SDOwrite(k+1, 0x1c13,0x00,FALSE,os, &ob4,EC_TIMEOUTRXM);
					 if (wkc_count==0)
					 {
						 printf("clear pdos error\n");
					 }
					os=sizeof(ob2); ob2 = 0x1600;	//1st RxPDO mapping, check MAXPOS ESI
					//0x1c12 is Index of Sync Manager 2 PDO Assignment (output RxPDO), CA (Complete Access) must be TRUE
					wkc_count=ec_SDOwrite(k+1, 0x1c12,0x01,FALSE,os, &ob2,EC_TIMEOUTRXM);	//change slave position (k+1) if needed
					 if (wkc_count==0)
					 {
						 printf("RxPDO assignment error\n");
						 return FALSE;
					 }
		
					os=sizeof(ob4); ob4 = 0x01;
					wkc_count=ec_SDOwrite(k+1, 0x1c12,0x00,FALSE,os, &ob4,EC_TIMEOUTRXM);
					os=sizeof(ob2); ob2 = 0x1a00;	//TxPDO, check MAXPOS ESI
					 //0x1c13 is Index of Sync Manager 3 PDO Assignment (input TxPDO), CA (Complete Access) must be TRUE
					 wkc_count=ec_SDOwrite(k+1, 0x1c13,0x01,FALSE,os, &ob2,EC_TIMEOUTRXM); //change slave position (k+1) if needed
					 if (wkc_count==0)
					 {
						 printf("TxPDO assignment error\n");
						 return FALSE;
					 }
					 os=sizeof(ob4); ob4 = 0x01;
					wkc_count=ec_SDOwrite(k+1, 0x1c13,0x00,FALSE,os, &ob4,EC_TIMEOUTRXM);
				 }
			 }
			 //PDO re-mapping****************************************************************************************************

#ifdef _WRITE_MODEOP_SDO
			 uint8 modeOp=OP_MODE_CYCLIC_SYNC_POSITION;
			  //write mode of operation by SDO
			  for (i=0; i<NUMOFMAXPOS_DRIVE; ++i)
			  {
				  os=sizeof(modeOp);
				  ec_SDOwrite(i+1, 0x6060, 0x0, FALSE, os, &modeOp, EC_TIMEOUTRXM); //set mode of operation by SDO, &modeOP = 0x08 -> CSP
			  }
#endif

			 ec_config_map(&IOmap);
			 
#ifdef _USE_DC
			 ec_configdc();
#endif	//Check SAFE OPERATION
			 rt_printf("Slaves mapped, state to SAFE_OP.\n"); //rt_printf == printf( //in trong thoi gian thuc)
			 /* wait for all slaves to reach SAFE_OP state */
			 ec_statecheck(0, EC_STATE_SAFE_OP,  EC_TIMEOUTSTATE * 4);
			 //                 0X04                2000000=2ms*4=8ms
#ifdef _USE_DC
			 //FOR DC----
			 /* configure DC options for every DC capable slave found in the list */
			 rt_printf("DC capable : %d\n",ec_configdc());
			 //---------------
#endif
			 oloop = ec_slave[0].Obytes;
			 if ((oloop == 0) && (ec_slave[0].Obits > 0)) oloop = 1;
			 //if (oloop > 8) oloop = 8;
			 iloop = ec_slave[0].Ibytes;
			 if ((iloop == 0) && (ec_slave[0].Ibits > 0)) iloop = 1;
			 //if (iloop > 8) iloop = 8;

			 rt_printf("segments : %d : %d %d %d %d\n",ec_group[0].nsegments ,ec_group[0].IOsegment[0],ec_group[0].IOsegment[1],ec_group[0].IOsegment[2],ec_group[0].IOsegment[3]);

			 rt_printf("Request operational state for all slaves\n");
			 expectedWKC = (ec_group[0].outputsWKC * 2) + ec_group[0].inputsWKC;
			 rt_printf("Calculated workcounter %d\n", expectedWKC);
			 ec_slave[0].state = EC_STATE_OPERATIONAL;
			 /* send one valid process data to make outputs in slaves happy*/
			 ec_send_processdata();
			 ec_receive_processdata(EC_TIMEOUTRET);
			 /* request OP state for all slaves */

			 ec_writestate(0);
			 ec_statecheck(0, EC_STATE_OPERATIONAL, EC_TIMEOUTSTATE); //wait for OP

			if (ec_slave[0].state == EC_STATE_OPERATIONAL)
			{
				rt_printf("Operational state reached for all slaves.\n");
				wkc_count = 0;

				for (k=0; k<NUMOFMAXPOS_DRIVE; ++k)
				{
					maxpos_drive_pt[k].ptOutParam=(MAXPOS_DRIVE_RxPDO_t*) ec_slave[k+1].outputs; //ptOUT -> rx
					maxpos_drive_pt[k].ptInParam= (MAXPOS_DRIVE_TxPDO_t*) ec_slave[k+1].inputs; //ptIn -> TX
					maxpos_drive_pt[k].ptOutParam->ModeOfOperation=OP_MODE_CYCLIC_SYNC_POSITION;
				}
				inOP = TRUE;
            }
            else //At least 1 servo not reack OP STATE
            {
                rt_printf("Not all slaves reached operational state.\n");
                ec_readstate();
                for(i = 1; i<=ec_slavecount ; i++)
                {
                    if(ec_slave[i].state != EC_STATE_OPERATIONAL)
                    {
                        rt_printf("Slave %d State=0x%2.2x StatusCode=0x%4.4x : %s\n",
                            i, ec_slave[i].state, ec_slave[i].ALstatuscode, ec_ALstatuscode2string(ec_slave[i].ALstatuscode));
                    }
                }
				for (i=0; i<NUMOFMAXPOS_DRIVE; ++i)
					ec_dcsync01(i+1, FALSE, 0, 0, 0); // SYNC0,1 
            }

        }
        else
        {
            printf("No slaves found!\n");
            inOP=FALSE;
        }

    }
    else
    {
        rt_printf("No socket connection on %s\nExcecute as root\n", ecat_ifname);
		return FALSE;
    }

	return inOP;
}


// main task
void mainrun(void *arg) //argument : doi so
{
	RTIME now, previous;
	unsigned long ready_cnt=0;
	uint16_t controlword=0;
	int ival=0, i;

	if (ecat_init()==FALSE)
	{
		run =0;
		printf("fail\n");
		return;	//all initialization stuffs here
	}	
	rt_task_sleep(1e6); //don vi dung la ns -> 10^6 ns => 10^-3 s -> 1ms
	
#ifdef _USE_DC
	//for dc computation
	long  long toff;
	long long cur_DCtime=0, max_DCtime=0;
	unsigned long long  cur_dc32=0, pre_dc32=0;
	int32_t shift_time=380000; //dc event shifted compared to master reference clock
	long long  diff_dc32;

	for (i=0; i<NUMOFMAXPOS_DRIVE; ++i)
		ec_dcsync0(1+i, TRUE, cycle_ns, 0); // SYNC0,1 on each slave

	RTIME cycletime=cycle_ns, cur_time=0;
	RTIME cur_cycle_cnt=0, cycle_time;
	RTIME remain_time, dc_remain_time;
	toff = 0;
	
	RTIME rt_ts;
	//get DC time for first time
	ec_send_processdata();
	
	cur_time=rt_timer_read();			//get current master time , rt_timer_read is function in API XENOMAI
	cur_cycle_cnt=cur_time/cycle_ns;	//calcualte number of cycles has passed
	cycle_time=cur_cycle_cnt*cycle_ns;	//thoi gian full all chu ky = chu ky dem duoc x 1 chu ky
	remain_time = cur_time%cycle_ns;	//remain time to next cycle, test only, lay phan du
	
	rt_printf("cycle_counter=%lld\n", cur_cycle_cnt);
	rt_printf("remain_time=%lld\n", remain_time);
	
	wkc = ec_receive_processdata(EC_TIMEOUTRET); 	//get wkc reference DC time
	cur_dc32= (uint64_t) (ec_DCtime); // & 0xffffffff);	//only consider first 64
	dc_remain_time=cur_dc32%cycletime;				//remain time to next cycle of REF clock, update to master
	rt_ts = cycle_time+dc_remain_time;					//update master time to REF clock
	
	rt_printf("dc remain_time=%lld\n", dc_remain_time);
	rt_task_sleep_until(rt_ts); //Ngung task cho toi khi du thoi gian computation

#else  //nonDC, not define macro USE_DC
	ec_send_processdata();
	rt_task_set_periodic(NULL, TM_NOW, cycle_ns); //TM_NOW -> constant representative for time at now , task will conduct instantly) with certain cycle 
#endif
	FILE *fp; //Open file to write
	fp = fopen("data.csv", "w+");
	while (run)
	{
	   //wait for next cycle	

#ifdef _USE_DC		   
		rt_ts+=(RTIME) (cycle_ns + toff); //rt_ts : time update from master to ref
		rt_task_sleep_until(rt_ts);
#else
		rt_task_wait_period(NULL); //wait until task complete and start new cycle
#endif
	   previous = rt_timer_read();
	   ec_send_processdata();
	   wkc = ec_receive_processdata(EC_TIMEOUTRET);
	   if (wkc<3*(NUMOFMAXPOS_DRIVE)) 
		   recv_fail_cnt++;
	   now = rt_timer_read();
	   ethercat_time = (long) (now - previous);
	   

#ifdef _USE_DC	   
	   cur_dc32= (uint64_t) (ec_DCtime);// & 0xffffffff); 	//use 64 bit
	   if (cur_dc32>pre_dc32)							//normal case
		   {diff_dc32=cur_dc32-pre_dc32;}
	   else	
			{diff_dc32=pre_dc32-cur_dc32; 								//64-bit data overflow
		   //diff_dc32=(0xffffffff-pre_dc32)+cur_dc32;
		   }
	   pre_dc32=cur_dc32;
	   cur_DCtime+=diff_dc32;
	   toff=dc_pi_sync(cur_DCtime, cycletime, shift_time); //return adjust time (diff)
	   if (cur_DCtime>max_DCtime) max_DCtime=cur_DCtime; //understand
#endif	
	
	   //servo-on	
	   for (i=0; i<NUMOFMAXPOS_DRIVE; ++i)
	   {
		   controlword=0;
		   started[i]=ServoOn_GetCtrlWrd(maxpos_drive_pt[i].ptInParam->StatusWord, &controlword);
		   maxpos_drive_pt[i].ptOutParam->ControlWord=controlword;
		   if (started[i]) ServoState |= (1<<i);
	   }
	   //after for ,servo state = 00000111

	   if (ServoState == (1<<NUMOFMAXPOS_DRIVE)-1) //all servos are in ON state (00000001<<3 -> 00001000-00000001=00000111)
	   {
		   if (servo_ready==0) 
			servo_ready=1;
	   }
		if (servo_ready) ready_cnt++;
		if (ready_cnt>=3000) //wait for 3s after servo-on
		{
			ready_cnt=10000;
			sys_ready=1;
		}

		if (sys_ready)
		{
			
			ival=(int) (3*sine_amp*(sin(PI2*f*gt+3.14159/2)))-3*sine_amp;
			/* //Luc fuzzy (Newton)
			if(gt<=0.5)
			{
			ival=(int) (5*sine_amp*(sin(3.14159265*gt*4+3.14159265/2)))-5*sine_amp;
			}
			
		if (ival>-83886070)
		{
		if (gt <= 1)
			{

				l1 = l1 + gt*10;
				l2 = l2 + gt*10;S
				l3 = l3 + gt*10;
				
				ival = -gt*gt*gt*64000000/6;
				
			}
			if (gt > 1 && gt <=2)
			{
				
				l1 = l1 - gt*10;
				l2 = l2 - gt*10;
				l3 = l3 - gt*10;
				ival= -8*8000000/6-64000000*1*(gt-1)-64000000*1*0.5*(gt-1)*(gt-1)+ (gt-1)*(gt-1)*(gt-1)*64000000/6;
			}
		}
		
			if (gt <= 2)
			{
				x = X;
				y = Y;
				z = Z;
				
				X = 0;// + ((3*gt*gt)/(2*2)-2*gt*gt*gt/(2*2*2))*(100);
				Y = 0;// ((3*gt*gt)/(2*2)-2*gt*gt*gt/(2*2*2))*(100);
				if (gt <= 0.1)
				{
					Z = ZZ -  4500*gt*gt;
				} else
				{
					Z = ZZ -45 - *(gt-0.1);
				}
				
				l1 = l1 + inv_kine(X, Y, Z, 1)-inv_kine(x, y, z, 1);
				l2 = l2 + inv_kine(X, Y, Z, 2)-inv_kine(x, y, z, 2);
				l3 = l3 + inv_kine(X, Y, Z, 3)-inv_kine(x, y, z, 3);
			}
			
			if (gt > 2 && gt <= 12)
			{
				x = X;
				y = Y;
				z = Z;
				
				X = 0 + 150*sin((3*(gt-2)*(gt-2)/(10*10)-2*(gt-2)*(gt-2)*(gt-2)/(10*10*10))*(2*3.14159-0));
				Y = 0;// + (3*(gt-2)*(gt-2)/(10*10)-2*(gt-2)*(gt-2)*(gt-2)/(10*10*10))*(-250);
				Z = ZZ -150 + 100*cos((3*(gt-2)*(gt-2)/(10*10)-2*(gt-2)*(gt-2)*(gt-2)/(10*10*10))*(2*3.14159-0));
				 
				
				l1 = l1 + inv_kine(X, Y, Z, 1)-inv_kine(x, y, z, 1);
				l2 = l2 + inv_kine(X, Y, Z, 2)-inv_kine(x, y, z, 2);
				l3 = l3 + inv_kine(X, Y, Z, 3)-inv_kine(x, y, z, 3);
			}
			
			if (gt > 12 && gt <= 15)
			{
				
				x = X;
				y = Y;
				z = Z;
				
				X = 0;//100 + ((3*(gt-8)*(gt-8))/(2*2)-2*(gt-8)*(gt-8)*(gt-8)/(2*2*2))*(-100);
				Y = 0;//-100 + ((3*(gt-12)*(gt-12))/(2*2)-2*(gt-12)*(gt-12)*(gt-12)/(2*2*2))*(100);
				Z = ZZ - 50 +(3*(gt-12)*(gt-12)/(3*3)-2*(gt-12)*(gt-12)*(gt-12)/(3*3*3))*(50);
				
				l1 = l1 + inv_kine(X, Y, Z, 1)-inv_kine(x, y, z, 1);
				l2 = l2 + inv_kine(X, Y, Z, 2)-inv_kine(x, y, z, 2);
				l3 = l3 + inv_kine(X, Y, Z, 3)-inv_kine(x, y, z, 3);
			}
			*/
			
				
			if (d[s] == 1)
			{
				direct(a[s],b[s],c[s]); // a is X, b is Y, c is Z
			}
			if (d[s] == 2)
			{
				circle(a[s],b[s],c[s]); // a is R, b is first radius, c is last radius
			}
			if (d[s] == 3)
			{
				 slp(a[s],b[s],c[s]); // a is time (second) 
			}
			if (d[s]==4)
			{
				directNofuzzy(a[s],b[s],c[s]);
			}
			if (d[s]==5)
			{
				circleNoFuzzy(a[s],b[s],c[s]);
			}
			
			/*
			if (gt <=10)
			{
			ival = -gt*8388607; //1 round
		}
			if (gt >= 30 && gt <=40)
			{
				ival = -83886070 + (gt-30)*8388607;
		}	
		
			*/
			
			/*
					maxpos_drive_pt[0].ptOutParam->TargetPosition= ivall(l1)/181 + zeropos[0];
				
					maxpos_drive_pt[1].ptOutParam->TargetPosition= ivall(l2)/181 + zeropos[1];
				
					maxpos_drive_pt[2].ptOutParam->TargetPosition= ivall(l3)/181 + zeropos[2];
					
				*/	
					maxpos_drive_pt[0].ptOutParam->TargetPosition=ival + zeropos[0];
				
					maxpos_drive_pt[1].ptOutParam->TargetPosition=ival + zeropos[1];
				
					maxpos_drive_pt[2].ptOutParam->TargetPosition=ival + zeropos[2];
					if (((cur_DCtime - 380000) % cycletime)<900000)
						error = (cur_DCtime - 380000) % cycletime;//+cycletime;
						else
						error = (cur_DCtime - 380000) % cycletime;
					
			if (gt >= 0){
			fprintf(fp, "%f, %lld\n",gt,error);//l1/(1000*period));//*defuzzified_output(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6,Z))); // Write the data rows
		//(reftime - shift_time) % cycletime
		//fprintf(fp, "%0.8f, %0.2f\n",gt,max3(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6)/100); // Write the data rows
		//fprintf(fp, "%0.8f, %0.2f\n",gt,(((maxpos_drive_pt[0].ptInParam->PositionActualValue-prepos)/period)*181)/83886070);//max3(weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6)/100); // Write the data rows
		
		//fprintf(fp, "%0.8f, %0.2f, %0.2f\n",gt,weight.weight_1+400,weight.weight_2+400);//,weight.weight_2,weight.weight_3,weight.weight_4,weight.weight_5,weight.weight_6); // Write the data rows
		
		//fprintf(fp, "%0.8f, %i, %i, %i, %i, %i, %i\n",gt,maxpos_drive_pt[0].ptInParam->PositionActualValue, maxpos_drive_pt[0].ptOutParam->TargetPosition,maxpos_drive_pt[1].ptInParam->PositionActualValue, maxpos_drive_pt[1].ptOutParam->TargetPosition,maxpos_drive_pt[2].ptInParam->PositionActualValue, maxpos_drive_pt[2].ptOutParam->TargetPosition);
		//fprintf(fp, "%0.8f, %i, %i, %i\n",gt,maxpos_drive_pt[0].ptInParam->PositionActualValue,maxpos_drive_pt[1].ptInParam->PositionActualValue,maxpos_drive_pt[2].ptInParam->PositionActualValue);
		//fprintf(fp, "%0.8f, %i\n",gt,abs(maxpos_drive_pt[0].ptInParam->PositionActualValue-maxpos_drive_pt[0].ptOutParam->TargetPosition)-abs(maxpos_drive_pt[2].ptInParam->PositionActualValue-maxpos_drive_pt[2].ptOutParam->TargetPosition));//,maxpos_drive_pt[1].ptInParam->PositionActualValue,maxpos_drive_pt[2].ptInParam->PositionActualValue);
		//prepos=maxpos_drive_pt[0].ptInParam->PositionActualValue;
			}
			if (gt >=60)
			{
			fclose(fp);}
		
		prepos=maxpos_drive_pt[0].ptInParam->PositionActualValue; 
		pre=maxpos_drive_pt[0].ptOutParam->TargetPosition;
		gt+=period;
		}
		
		else
		{
			for (i=0; i<NUMOFMAXPOS_DRIVE; ++i)
			{
				zeropos[i]=maxpos_drive_pt[i].ptInParam->PositionActualValue;
				maxpos_drive_pt[i].ptOutParam->TargetPosition=zeropos[i];
			}
		}
		
		
		if (sys_ready)
			if (worst_time<ethercat_time) worst_time=ethercat_time; //ethercat_time = now-preus time
	}

	rt_task_sleep(cycle_ns);
#ifdef _USE_DC
	for (i=0; i<NUMOFMAXPOS_DRIVE; ++i)
		ec_dcsync0(i+1, FALSE, 0, 0); // SYNC0,1 on slave 1
#endif

	//Servo OFF
	for (i=0; i<NUMOFMAXPOS_DRIVE; ++i)
	{
		maxpos_drive_pt[i].ptOutParam->ControlWord=0; //Servo OFF (Disable voltage, transition#9)
	}
	ec_send_processdata();
	wkc = ec_receive_processdata(EC_TIMEOUTRET);
	
	rt_task_sleep(cycle_ns);
	
	rt_printf("End simple test, close socket\n");
	/* stop SOEM, close socket */
	 printf("Request safe operational state for all slaves\n");
	 ec_slave[0].state = EC_STATE_SAFE_OP;
	 /* request SAFE_OP state for all slaves */
	 ec_writestate(0);
	 /* wait for all slaves to reach state */
	 ec_statecheck(0, EC_STATE_SAFE_OP,  EC_TIMEOUTSTATE);
	 ec_slave[0].state = EC_STATE_PRE_OP;
	 /* request SAFE_OP state for all slaves */
	 ec_writestate(0);
	 /* wait for all slaves to reach state */
	 ec_statecheck(0, EC_STATE_PRE_OP,  EC_TIMEOUTSTATE);

	ec_close();
}





void print_run(void *arg)
{
	int i;
	unsigned long itime=0;
	long stick=0;
	 
	rt_task_set_periodic(NULL, TM_NOW, 1e8);
	/*
	FILE *fp;
	fp = fopen("data.csv", "w+");
	* */
	while (run)
	{
		rt_task_wait_period(NULL); 	//wait for next cycle
		if (inOP==TRUE)
		{
		weight = hx711_weight(&loadcell, 1);
		//rt_printf("1: \t %0.2f \t 2: \t %0.2f \t 3: \t %0.2f \t 4: \t %0.2f \t 5: \t %0.2f \t 6:\t %0.2f\n" , weight.weight_1,weight.weight_2, weight.weight_3, weight.weight_4, weight.weight_5, weight.weight_6);
		//rt_printf("%0.2f      %0.2f     %0.2f     %0.2f     %0.2f    %0.2f\n" , weight.weight_1,weight.weight_2, weight.weight_3, weight.weight_4, weight.weight_5, weight.weight_6);
		//rt_printf("%0.2f \n", weight.weight_6);
		//fprintf(fp, "t,T1,T2,T3\n"); // Write the column headers
		//rt_printf("%0.8f,   %0.2f,   %0.2f,   %0.2f\n",gt,weight.weight_1+weight.weight_2,weight.weight_3+weight.weight_4,weight.weight_5+weight.weight_6); // Write the data rows
		/*
		if (gt >= 0){
		//fprintf(fp, "%0.8f, %0.2f, %0.2f, %0.2f, %0.2f, %0.2f, %0.2f\n",gt,weight.weight_1,weight.weight_2,weight.weight_3,weight.weight_4,weight.weight_5,weight.weight_6); // Write the data rows
		fprintf(fp, "%0.8f, %i, %i, %i, %i, %i, %i\n",gt,maxpos_drive_pt[0].ptInParam->PositionActualValue, maxpos_drive_pt[0].ptOutParam->TargetPosition,maxpos_drive_pt[1].ptInParam->PositionActualValue, maxpos_drive_pt[1].ptOutParam->TargetPosition,maxpos_drive_pt[2].ptInParam->PositionActualValue, maxpos_drive_pt[2].ptOutParam->TargetPosition);
		//fprintf(fp, "%0.8f, %i, %i, %i\n",gt,maxpos_drive_pt[0].ptInParam->PositionActualValue,maxpos_drive_pt[1].ptInParam->PositionActualValue,maxpos_drive_pt[2].ptInParam->PositionActualValue);
		
		if (gt >1000)
		{
		fclose(fp);}
		}
		 */

			if (!sys_ready)
			{
				if (stick==0)
					rt_printf("waiting for system ready...\n");
				if (stick%10==0)
					rt_printf("%i\n", stick/10);
				stick++;
			}
			else
			{
				itime++;
				rt_printf("Time=%06d.%01d, \e[32;1m fail=%ld\e[0m, ecat_T=%ld, maxT=%ld\n", itime/10, itime%10, recv_fail_cnt,  ethercat_time/1000, worst_time/1000);
				for(i=0; i<NUMOFMAXPOS_DRIVE; ++i)
				{
					/*rt_printf("CSD7_04BN1#%i\n", i+1);
					rt_printf("Status word = 0x%X\n", maxpos_drive_pt[i].ptInParam->StatusWord);
					rt_printf("Actual Position = %i / %i\n", maxpos_drive_pt[i].ptInParam->PositionActualValue, maxpos_drive_pt[i].ptOutParam->TargetPosition);
					rt_printf("\n");
					*/
				}
				//rt_printf("\n");

			}

		}
	}
}

void catch_signal(int sig)
{
	run=0;
	usleep(5e5);
	rt_task_delete(&motion_task);
	rt_task_delete(&print_task);
	exit(1);
}

int main(int argc, char const *argv[])
{
	signal(SIGTERM, catch_signal);
	signal(SIGINT, catch_signal);

	printf("SOEM (Simple Open EtherCAT Master)\nSimple test\n");
	mlockall(MCL_CURRENT | MCL_FUTURE);
	
	/*
	 
	uint8_t state = hx711_init(&loadcell, CLOCK, DATA1,DATA2,DATA3,DATA4,DATA5,DATA6);
	gpioSetMode(out, PI_OUTPUT);
	if (state == 1) return 0;
	hx711_coef_set(&loadcell, 211, 212, 217,213,212,217);
	hx711_tare(&loadcell,20);
    
    */
	cycle_ns=1000000; // nanosecond
	period=((double) cycle_ns)/((double) NSEC_PER_SEC);	//period in second unit
	if (argc > 1)
	{
		sine_amp=atoi(argv[1]);
	}
	printf("use default adapter %s\n", ecat_ifname);
	
	cpu_set_t cpu_set_ecat;
	CPU_ZERO(&cpu_set_ecat);
	CPU_SET(0, &cpu_set_ecat); //assign CPU#0 for ethercat task
	cpu_set_t cpu_set_print;
	CPU_ZERO(&cpu_set_print);
	CPU_SET(1, &cpu_set_print); //assign CPU#1 (or any) for main task

	
  	rt_task_create(&motion_task, "SOEM_motion_task", 0, 90, 0 );
	rt_task_set_affinity(&motion_task, &cpu_set_ecat); //CPU affinity for ethercat task
	
	rt_task_create(&print_task, "ec_printing", 0, 50, 0 );
	rt_task_set_affinity(&print_task, &cpu_set_print); //CPU affinity for printing task
		
	rt_task_start(&motion_task, &mainrun, NULL);
	rt_task_start(&print_task, &print_run, NULL);

	//rt_task_start(&loadcell_task, &loadcell_run, NULL);
	
   	while (run)
	{
		usleep(100000);
	}


   printf("End program\n");
   return (0);
}
