#include <stdio.h>
#include <stdlib.h>

#define timeout 20000
#define _HX711_DELAY_US_LOOP	0
#define hx711_delay(x)  gpioDelay(x*1000)

typedef struct
{
  uint16_t      clk_pin;
  uint16_t      dat_pin;
  uint16_t      dat_pin2;
  uint16_t      dat_pin3;
  uint16_t      dat_pin4;
  uint16_t      dat_pin5;
  uint16_t      dat_pin6;
  int32_t       offset;
  int32_t       offset2;
  int32_t       offset3;
  int32_t       offset4;
  int32_t       offset5;
  int32_t       offset6;
  float         coef;
  float         coef2;
  float         coef3;
  float         coef4;
  float         coef5;
  float         coef6;

}hx711_t;

typedef struct
{
	int32_t data1;
	int32_t data2;
	int32_t data3;
	int32_t data4;
	int32_t data5;
	int32_t data6;

}data_t;

typedef struct
{
  float weight_1;
  float weight_2;
  float weight_3;
  float weight_4;
  float weight_5;
  float weight_6;
}weight_t;

typedef struct
{
	int64_t data1;
	int64_t data2;
	int64_t data3;
	int64_t data4;
	int64_t data5;
	int64_t data6;

}ave_t;

//#############################################################################################
void hx711_delay_us(void);
uint8_t hx711_init(hx711_t *hx711, uint16_t clk_pin, uint16_t dat_pin, uint16_t dat_pin2,
                uint16_t dat_pin3,uint16_t dat_pin4,uint16_t dat_pin5,uint16_t dat_pin6);
data_t hx711_value(hx711_t *hx711);
weight_t hx711_weight(hx711_t *hx711, uint16_t sample);
void hx711_tare(hx711_t *hx711, uint16_t sample);
void hx711_coef_set(hx711_t *hx711, float coef, float coef2, float coef3,
                    float coef4,float coef5,float coef6);
float hx711_coef_get(hx711_t *hx711);
void hx711_power_down(hx711_t *hx711);
void hx711_power_up(hx711_t *hx711);
