cd osal
make
cd ../oshw
make
cd ../soem
make
cd ../test/slaveInfo
make
cd ../xmc4800
make
cd ../xmc4800_dc
make
cd ..
cd ..


